(function($) {
	'use strict';
})(jQuery);